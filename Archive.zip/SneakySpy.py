class SneakySpy:
	def __init__(self):
		
	def parse(self):
